'use client';

import React from 'react';
import Image from 'next/image';
import { FiMic, FiX } from 'react-icons/fi';
import { useRouter } from 'next/navigation';

const SmileyWithHeadset = () => (
    <div className="relative filter drop-shadow-lg">
      <Image
        src="/smiley2.svg"
        alt="Smiley face with a headset"
        width={300}
        height={300}
        className="transform transition-transform duration-500 hover:scale-105"
      />
    </div>
);

const ControlButton = ({ icon: Icon, label, onClick }: { icon: React.ElementType, label: string, onClick?: () => void }) => (
    <div className="flex flex-col items-center gap-2">
        <button 
            onClick={onClick}
            className="flex items-center justify-center w-20 h-20 border border-gray-400 rounded-full text-gray-600 transform transition-all duration-300 ease-in-out hover:bg-gray-200/50 hover:scale-110 active:scale-95"
        >
            <Icon className="w-8 h-8" />
        </button>
        <span className="text-gray-600 font-inter">{label}</span>
    </div>
);

export default function CallPage() {
    const router = useRouter();

    return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-[#FBF3E9] text-gray-800 font-inter p-4">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                <SmileyWithHeadset />
            </div>
            
            <div className="absolute bottom-16 flex items-center gap-8">
                <ControlButton icon={FiMic} label="Mute" />
                <ControlButton icon={FiX} label="Exit" onClick={() => router.push('/transcript')} />
            </div>
        </div>
    );
} 