'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { FiX, FiCopy, FiDownload } from 'react-icons/fi';
import Image from 'next/image';

const Squiggle = () => <Image src="/squiggle.svg" alt="Squiggle" width={69} height={17} />;

const InfoCard = ({ title, children }: { title: string, children: React.ReactNode }) => (
    <div className="border border-gray-400 rounded-3xl p-6 bg-white/30 backdrop-blur-sm">
        <h2 className="font-semibold text-lg mb-3">{title}</h2>
        <div className="text-gray-700 space-y-2">
            {children}
        </div>
    </div>
);

const LinedListItem = ({ text }: { text: string }) => (
    <div className="border-b border-gray-400 pb-2">
        {text}
    </div>
);

const ControlButton = ({ icon: Icon, label, onClick }: { icon: React.ElementType, label: string, onClick?: () => void }) => (
    <div className="flex flex-col items-center gap-2">
        <button 
            onClick={onClick}
            className="flex items-center justify-center w-16 h-16 border border-gray-400 rounded-full text-gray-600 transform transition-all duration-300 ease-in-out hover:bg-gray-200/50 hover:scale-110 active:scale-95"
        >
            <Icon className="w-7 h-7" />
        </button>
        <span className="text-gray-600 text-sm">{label}</span>
    </div>
);

export default function SummaryPage() {
    const router = useRouter();

    return (
        <div className="min-h-screen bg-[url('/backround.svg')] bg-cover bg-center font-inter text-gray-800 p-8">
            <header className="flex justify-between items-center mb-12">
                <div className="flex items-center gap-4">
                    <button 
                      onClick={() => router.back()} 
                      className="p-2 rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 transition-colors duration-200 hover:bg-gray-500/10"
                      aria-label="Go back"
                    >
                        <Squiggle />
                    </button>
                    <p className="text-lg font-inter">Date: Sat Jun 21, 2025</p>
                </div>
                <h1 className="font-roboto-mono font-normal text-6xl tracking-wider">Summary</h1>
                <div className="flex items-center gap-6">
                    <ControlButton icon={FiX} label="Exit" onClick={() => router.push('/dashboard')} />
                    <ControlButton icon={FiCopy} label="Copy" />
                    <ControlButton icon={FiDownload} label="Save" onClick={() => router.push('/journal')} />
                </div>
            </header>

            <main className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Left Column */}
                <div className="space-y-8">
                    <InfoCard title="How was my day:">
                        <p>Today I needed to talk because I've been feeling mentally drained and emotionally all over the place. I kept procrastinating even though I had things I genuinely wanted to get done. I mentioned how I've been doom-scrolling to avoid starting my biology assignment, and that the guilt is starting to pile up. Even though I know I'm capable, it's like my brain is in a fog and everything feels heavier than it should. I wasn't looking for a solution—I just needed to be heard without judgment and maybe feel less alone in it.</p>
                    </InfoCard>
                    <InfoCard title="Overall Mood/Tone:">
                        <LinedListItem text="1. Nervous" />
                        <LinedListItem text="2. Sad" />
                        <LinedListItem text="3. Overwhelmed" />
                    </InfoCard>
                </div>

                {/* Right Column */}
                <div className="space-y-8">
                    <InfoCard title="Advise / Next Steps:">
                        <LinedListItem text="1. Just open the bio assignment—no pressure to start." />
                        <LinedListItem text="2. Set a 10-min timer and write a little." />
                        <LinedListItem text="3. Treat yourself after—snack or fresh air." />
                    </InfoCard>
                    <InfoCard title="Extra Notes:">
                        <div className="h-40"></div>
                    </InfoCard>
                </div>
            </main>
        </div>
    );
} 