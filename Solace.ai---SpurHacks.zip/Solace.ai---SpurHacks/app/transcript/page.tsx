'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { FiX, FiFileText, FiDownload } from 'react-icons/fi';

const mockTranscript = [
    {
        speaker: 'user',
        text: 'Whatever I am saying to you, is it being recorded?',
        timestamp: '00:02',
    },
    {
        speaker: 'ai',
        text: "Yeah, our conversation is recorded so that I can respond and keep track of what we've talked about. But if you have any concerns about privacy, definitely let me know!",
        timestamp: null,
    },
    {
        speaker: 'user',
        text: "What I'm saying, could it be made in a transcript after the conversation ends?",
        timestamp: '00:08',
    },
    {
        speaker: 'ai',
        text: "Absolutely. Once our conversation is complete, a full transcript will be generated. You'll have options to view it, save it, or export it.",
        timestamp: null,
    },
    {
        speaker: 'user',
        text: 'Okay, that sounds perfect. I just wanted to be sure. Thanks for clarifying!',
        timestamp: '00:15',
    },
    {
        speaker: 'ai',
        text: "You're welcome! Let's continue whenever you're ready.",
        timestamp: null,
    },
];

const ChatBubble = ({ speaker, text, timestamp }: { speaker: string, text: string, timestamp: string | null }) => {
    const isUser = speaker === 'user';
    return (
        <div className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} w-full`}>
            <div className={`px-6 py-4 border border-gray-400 rounded-3xl ${isUser ? 'bg-white/50' : 'bg-white/70'} max-w-2xl`}>
                <p className="text-gray-800 font-inter">{text}</p>
            </div>
            {timestamp && <span className="mt-2 text-xs text-gray-500 font-inter">{timestamp}</span>}
        </div>
    );
};

const ControlButton = ({ icon: Icon, label, onClick }: { icon: React.ElementType, label: string, onClick?: () => void }) => (
    <div className="flex flex-col items-center gap-2">
        <button 
            onClick={onClick}
            className="flex items-center justify-center w-20 h-20 border border-gray-400 rounded-full text-gray-600 transform transition-all duration-300 ease-in-out hover:bg-gray-200/50 hover:scale-110 active:scale-95"
        >
            <Icon className="w-8 h-8" />
        </button>
        <span className="text-gray-600 font-inter">{label}</span>
    </div>
);


export default function TranscriptPage() {
    const router = useRouter();

    return (
        <div className="min-h-screen flex flex-col justify-between bg-[#FBF3E9] font-inter p-8 md:p-16">
            <div className="flex-1 flex flex-col items-center justify-center gap-8 w-full">
                {mockTranscript.map((message, index) => (
                    <ChatBubble key={index} {...message} />
                ))}
            </div>

            <div className="flex items-center justify-center gap-8 mt-16">
                <ControlButton icon={FiX} label="Exit" onClick={() => router.push('/dashboard')} />
                <ControlButton icon={FiFileText} label="View Entry" onClick={() => router.push('/summary')} />
                <ControlButton icon={FiDownload} label="Save" onClick={() => router.push('/view-in-notion')} />
            </div>
        </div>
    );
} 